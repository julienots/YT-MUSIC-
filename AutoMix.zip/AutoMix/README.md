# AutoMix — génération automatique de playlists YouTube Music

App Android native (Kotlin) qui se connecte à ton compte Google et crée
réellement des playlists sur YouTube / YouTube Music à partir d'artistes
ou de genres que tu donnes en seed.

## Important — ce qui n'est PAS possible

YouTube Music n'a pas d'API publique et il n'existe aucun moyen officiel
d'accéder à son algorithme de recommandation. Cette app utilise l'**API
YouTube Data v3** (officielle) : elle cherche des morceaux liés à tes
seeds via `search.list`, puis crée/remplit une vraie playlist sur ton
compte avec `playlists.insert` / `playlistItems.insert`. Ces playlists
apparaissent ensuite dans l'appli YouTube Music, puisqu'elles partagent
le même compte Google.

## Étapes obligatoires avant de compiler (à faire une seule fois)

1. Va sur https://console.cloud.google.com/ et crée un projet (ou réutilise-en un).
2. Dans "APIs & Services" → "Library", active **YouTube Data API v3**.
3. Dans "APIs & Services" → "Credentials", crée un identifiant **OAuth 2.0
   Client ID** de type **Android** :
   - Package name : `com.julien.automix`
   - SHA-1 : celui de ta clé de debug (`keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android`)
4. Dans "OAuth consent screen", ajoute ton propre compte Google comme
   "testeur" (tant que l'app n'est pas publiée, seuls les comptes listés
   peuvent se connecter).
5. Aucune clé n'est à coller dans le code : le SDK Google Sign-In
   identifie automatiquement l'app grâce au package name + SHA-1
   enregistrés à l'étape 3.

## Ouvrir le projet

Ouvre le dossier `AutoMix/` dans Android Studio (il le reconnaîtra comme
projet Gradle), laisse la synchronisation se faire, puis Run.

## Utilisation

1. "Se connecter avec Google" → accepte le scope YouTube demandé.
2. Renseigne des artistes/genres séparés par des virgules.
3. Donne un nom à la playlist.
4. "Générer et créer la playlist" → la playlist est créée en **privé**
   sur ton compte, avec les morceaux trouvés pour chaque seed.

## Limites connues

- La "recommandation" est une recherche par pertinence YouTube, pas
  l'algorithme personnel de Google — c'est la meilleure approximation
  possible sans accès à leurs données internes.
- L'API YouTube Data v3 a un quota gratuit journalier (10 000 unités) ;
  une recherche coûte 100 unités, donc ~100 recherches/jour max avec le
  quota par défaut.

## Compiler automatiquement via GitHub Actions (sans Android Studio)

Un workflow est fourni dans `.github/workflows/build.yml`. Il se déclenche
à chaque push sur `main` (ou manuellement depuis l'onglet "Actions" de
GitHub → "Run workflow"), compile l'APK debug, et le dépose en
téléchargement dans l'onglet "Actions" → le run → "Artifacts".

### Garder la même clé de debug (important pour Google Sign-In)

Le SHA-1 que tu as enregistré dans Google Cloud Console correspond à TA
clé de debug locale (`~/.android/debug.keystore`). Si le runner GitHub
en génère une autre à la volée, son SHA-1 ne correspondra plus et la
connexion Google échouera sur l'APK compilé par Actions.

Pour éviter ça, donne au workflow ta propre clé de debug via un secret
GitHub :

1. Encode ta clé en base64 :
   ```
   base64 -i ~/.android/debug.keystore | tr -d '\n' > debug_keystore.b64
   ```
2. Dans GitHub → Settings du repo → Secrets and variables → Actions →
   "New repository secret" :
   - Nom : `DEBUG_KEYSTORE_BASE64`
   - Valeur : le contenu de `debug_keystore.b64`
3. Relance le workflow — il restaure automatiquement cette clé avant de
   compiler, donc le SHA-1 reste identique à celui enregistré côté
   Google Cloud Console.

Si tu ne configures pas ce secret, le workflow compile quand même (avec
la clé de debug par défaut du runner), mais la connexion Google échouera
tant que tu n'auras pas ajouté ce SHA-1-là aussi comme client OAuth
supplémentaire dans Google Cloud Console.
