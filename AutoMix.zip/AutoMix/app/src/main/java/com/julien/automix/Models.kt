package com.julien.automix

// ---- Réponses de l'API YouTube Data v3 (uniquement les champs utilisés) ----

data class SearchListResponse(
    val items: List<SearchResultItem> = emptyList()
)

data class SearchResultItem(
    val id: SearchResultId? = null,
    val snippet: SearchResultSnippet? = null
)

data class SearchResultId(
    val videoId: String? = null
)

data class SearchResultSnippet(
    val title: String? = null,
    val channelTitle: String? = null
)

// ---- Création de playlist ----

data class PlaylistInsertBody(
    val snippet: PlaylistSnippet,
    val status: PlaylistStatus
)

data class PlaylistSnippet(
    val title: String,
    val description: String
)

data class PlaylistStatus(
    val privacyStatus: String = "private"
)

data class PlaylistResponse(
    val id: String? = null
)

// ---- Ajout d'un morceau à la playlist ----

data class PlaylistItemInsertBody(
    val snippet: PlaylistItemSnippet
)

data class PlaylistItemSnippet(
    val playlistId: String,
    val resourceId: ResourceId
)

data class ResourceId(
    val kind: String = "youtube#video",
    val videoId: String
)

data class PlaylistItemResponse(
    val id: String? = null
)
