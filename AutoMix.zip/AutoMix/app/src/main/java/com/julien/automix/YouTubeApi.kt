package com.julien.automix

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Interface Retrofit vers l'API YouTube Data v3.
 * Chaque appel reçoit le jeton OAuth de l'utilisateur en en-tête Authorization.
 */
interface YouTubeApi {

    @GET("search")
    suspend fun search(
        @Header("Authorization") auth: String,
        @Query("part") part: String = "snippet",
        @Query("q") query: String,
        @Query("type") type: String = "video",
        @Query("videoCategoryId") videoCategoryId: String = "10", // Musique
        @Query("maxResults") maxResults: Int = 6,
        @Query("order") order: String = "relevance"
    ): SearchListResponse

    @POST("playlists")
    suspend fun createPlaylist(
        @Header("Authorization") auth: String,
        @Query("part") part: String = "snippet,status",
        @Body body: PlaylistInsertBody
    ): PlaylistResponse

    @POST("playlistItems")
    suspend fun addPlaylistItem(
        @Header("Authorization") auth: String,
        @Query("part") part: String = "snippet",
        @Body body: PlaylistItemInsertBody
    ): PlaylistItemResponse

    companion object {
        private const val BASE_URL = "https://www.googleapis.com/youtube/v3/"

        fun create(): YouTubeApi {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logging)
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(YouTubeApi::class.java)
        }
    }
}
