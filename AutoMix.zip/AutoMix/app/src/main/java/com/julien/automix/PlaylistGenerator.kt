package com.julien.automix

/**
 * Logique de génération : à partir d'une liste de "seeds" (artistes/genres),
 * interroge l'API YouTube pour chaque seed, déduplique les résultats,
 * crée une playlist et y ajoute les morceaux trouvés.
 *
 * NB : il n'existe pas d'algorithme de recommandation "façon Google" accessible
 * publiquement — ceci reconstruit une recommandation simple par recherche +
 * pertinence + déduplication, seed par seed.
 */
class PlaylistGenerator(private val api: YouTubeApi) {

    /**
     * @param authToken jeton OAuth "Bearer xxx" déjà formaté
     * @param seeds liste d'artistes/genres saisis par l'utilisateur
     * @param playlistName nom de la playlist à créer
     * @param onLog callback pour afficher la progression dans l'UI
     * @return l'ID de la playlist créée
     */
    suspend fun generateAndCreate(
        authToken: String,
        seeds: List<String>,
        playlistName: String,
        onLog: (String) -> Unit
    ): String {
        val foundVideoIds = LinkedHashSet<String>()

        for (seed in seeds) {
            onLog("Recherche pour \"$seed\"…")
            try {
                val result = api.search(auth = authToken, query = seed)
                val ids = result.items.mapNotNull { it.id?.videoId }
                onLog("  → ${ids.size} morceau(x) trouvé(s)")
                foundVideoIds.addAll(ids)
            } catch (e: Exception) {
                onLog("  ⚠ Erreur sur \"$seed\" : ${e.message}")
            }
        }

        if (foundVideoIds.isEmpty()) {
            throw IllegalStateException("Aucun morceau trouvé pour ces seeds.")
        }

        onLog("Création de la playlist \"$playlistName\"…")
        val playlist = api.createPlaylist(
            auth = authToken,
            body = PlaylistInsertBody(
                snippet = PlaylistSnippet(
                    title = playlistName,
                    description = "Playlist générée automatiquement par AutoMix à partir de : ${seeds.joinToString(", ")}"
                ),
                status = PlaylistStatus(privacyStatus = "private")
            )
        )
        val playlistId = playlist.id
            ?: throw IllegalStateException("La création de la playlist a échoué (pas d'ID retourné).")

        onLog("Playlist créée (id=$playlistId). Ajout des morceaux…")

        var added = 0
        for (videoId in foundVideoIds) {
            try {
                api.addPlaylistItem(
                    auth = authToken,
                    body = PlaylistItemInsertBody(
                        snippet = PlaylistItemSnippet(
                            playlistId = playlistId,
                            resourceId = ResourceId(videoId = videoId)
                        )
                    )
                )
                added++
            } catch (e: Exception) {
                onLog("  ⚠ Échec ajout $videoId : ${e.message}")
            }
        }

        onLog("Terminé : $added morceau(x) ajouté(s) à \"$playlistName\".")
        return playlistId
    }
}
