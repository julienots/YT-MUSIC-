package com.julien.automix

import android.accounts.Account
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    // Scope OAuth nécessaire pour créer/modifier des playlists sur le compte de l'utilisateur.
    // "youtube" (et non "youtube.readonly") car on écrit des données.
    private val youtubeScope = Scope("https://www.googleapis.com/auth/youtube")

    private lateinit var googleSignInClient: GoogleSignInClient
    private var account: GoogleSignInAccount? = null

    private lateinit var accountText: TextView
    private lateinit var signInButton: Button
    private lateinit var seedsInput: EditText
    private lateinit var playlistNameInput: EditText
    private lateinit var generateButton: Button
    private lateinit var logText: TextView

    private val api = YouTubeApi.create()
    private val generator = PlaylistGenerator(api)

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val acc = task.getResult(Exception::class.java)
            onSignedIn(acc)
        } catch (e: Exception) {
            appendLog("Connexion annulée ou échouée : ${e.message}")
        }
    }

    // Relance l'action si Google demande une confirmation de consentement (UserRecoverableAuthException)
    private val consentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        appendLog("Consentement traité, relance la génération.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        accountText = findViewById(R.id.accountText)
        signInButton = findViewById(R.id.signInButton)
        seedsInput = findViewById(R.id.seedsInput)
        playlistNameInput = findViewById(R.id.playlistNameInput)
        generateButton = findViewById(R.id.generateButton)
        logText = findViewById(R.id.logText)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(youtubeScope)
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Si déjà connecté précédemment avec le bon scope, on réutilise le compte.
        val existing = GoogleSignIn.getLastSignedInAccount(this)
        if (existing != null && GoogleSignIn.hasPermissions(existing, youtubeScope)) {
            onSignedIn(existing)
        }

        signInButton.setOnClickListener {
            signInLauncher.launch(googleSignInClient.signInIntent)
        }

        generateButton.setOnClickListener {
            onGenerateClicked()
        }
    }

    private fun onSignedIn(acc: GoogleSignInAccount) {
        account = acc
        accountText.text = getString(R.string.signed_in_as, acc.email ?: acc.displayName ?: "")
        signInButton.text = "Connecté"
        signInButton.isEnabled = false
        generateButton.isEnabled = true
    }

    private fun onGenerateClicked() {
        val acc = account ?: run {
            Toast.makeText(this, "Connecte-toi d'abord.", Toast.LENGTH_SHORT).show()
            return
        }
        val seeds = seedsInput.text.toString()
            .split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        val playlistName = playlistNameInput.text.toString().trim().ifEmpty { "AutoMix — ${System.currentTimeMillis()}" }

        if (seeds.isEmpty()) {
            Toast.makeText(this, "Indique au moins un artiste ou genre.", Toast.LENGTH_SHORT).show()
            return
        }

        generateButton.isEnabled = false
        logText.text = ""

        CoroutineScope(Dispatchers.Main).launch {
            try {
                val token = fetchAccessToken(acc)
                if (token == null) {
                    appendLog("Impossible d'obtenir le jeton d'accès. Réessaie après avoir donné ton consentement.")
                    return@launch
                }
                generator.generateAndCreate(
                    authToken = "Bearer $token",
                    seeds = seeds,
                    playlistName = playlistName,
                    onLog = { msg -> appendLog(msg) }
                )
            } catch (e: Exception) {
                appendLog("Erreur : ${e.message}")
            } finally {
                generateButton.isEnabled = true
            }
        }
    }

    /**
     * Récupère un jeton OAuth via GoogleAuthUtil (nécessite un appel réseau bloquant,
     * donc exécuté sur Dispatchers.IO). Si l'utilisateur n'a pas encore donné son
     * consentement pour le scope YouTube, une UserRecoverableAuthException est levée :
     * on affiche alors l'écran de consentement Google.
     */
    private suspend fun fetchAccessToken(acc: GoogleSignInAccount): String? {
        val account: Account = acc.account ?: return null
        return withContext(Dispatchers.IO) {
            try {
                GoogleAuthUtil.getToken(
                    this@MainActivity,
                    account,
                    "oauth2:https://www.googleapis.com/auth/youtube"
                )
            } catch (e: UserRecoverableAuthException) {
                withContext(Dispatchers.Main) {
                    consentLauncher.launch(e.intent)
                }
                null
            }
        }
    }

    private fun appendLog(message: String) {
        logText.append(if (logText.text.isEmpty()) message else "\n$message")
    }
}
